To install node modules, execute the following command.

### yarn 

To run the react application, execute the following command

### npm start